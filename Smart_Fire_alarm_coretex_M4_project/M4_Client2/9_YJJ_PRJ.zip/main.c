/******************************************************************************
USART 1 : wifi
USART2 : printf
MCU   ESP8266 Serial WIFI ���  ��
  3.3V                 VCC, CH_PD
 GND                  GND

CortexM4            ESP8266 Serial WIFI ���  ��
PORTA9(USART1 TX)             RX  
PORTA10(USART1 RX)             TX
GND                         GND
PORTC0~11 : FND
PORTB8~15 : LED
PORTA0(ADC)    : VRES
******************************************************************************/
// stm32f4xx�� �� �������͵��� ������ �������
#include "stm32f4xx.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "wifi.h"
#include "lcd.h"

volatile unsigned char data1;
volatile unsigned char Rflag1 ; // ���� ���ͷ�Ʈ�� �߻��ߴ����� �˾ƺ��� ����
volatile unsigned char data2;
volatile unsigned char Rflag2 ; // ���� ���ͷ�Ʈ�� �߻��ߴ����� �˾ƺ��� ����

volatile unsigned long systick_count;

volatile unsigned long int t_cnt;
extern volatile char uart1_rxdata[5][100];
volatile char fire_flag;

#define ARR_CNT 5

void Serial_Send1(unsigned char t)
{
  USART_SendData(USART1, t);
  while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void Serial_Send2(unsigned char t)
{
  USART_SendData(USART2, t);
  while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}
void TX1_string(char *string)			/* transmit a string by USART2 */
{
  while(*string != '\0')
  { 
    USART_SendData(USART1,*string);
     while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    string++;
  }
}

void USART1_IRQHandler(void)
{
  if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
    data1 = USART_ReceiveData(USART1);
    Rflag1 = 1; // ���� ���ͷ�Ʈ ����� ��1���� ����� �ش�.
  }
}

void USART2_IRQHandler(void)
{
  if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
  {
    data2 = USART_ReceiveData(USART2);
    Rflag2 = 1; // ���� ���ͷ�Ʈ ����� ��1���� ����� �ش�.
  }
}

int putchar(int ch)
{
  while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
  USART_SendData(USART2,ch);
  return ch;
}

void TIM7_IRQHandler(void)              //4ms
{
  if(TIM_GetITStatus(TIM7, TIM_IT_Update) != RESET)
  {
    TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
    t_cnt++ ;
    systick_count++;

    if(t_cnt >= 250)             //1s
    {
      t_cnt = 0;
      if(fire_flag) GPIO_ToggleBits(GPIOB, GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
    }
  }
}

int main()
{
  char senddata[100]={0}; //wifi send
  char recvdata[100]={0}; //wifi recv
  char *pToken;
  char *pArray[ARR_CNT]={0};
  
  GPIO_InitTypeDef   GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure;
  NVIC_InitTypeDef   NVIC_InitStructure;
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;                       //TIM7

  int i;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOC, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);        //TIM7  
  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|
                                             GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
  //GPIO_SetBits(GPIOC, GPIO_Pin_14|GPIO_Pin_15);
  GPIO_ResetBits(GPIOC, GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
  
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);     //USART2_TX
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);    //USART2_RX
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_10;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);     //USART1_TX
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);    //USART1_RX
  
  //���ͷ�Ʈ enable �� Priority ����.
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_Init(&NVIC_InitStructure);   

  NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;               //TM7
  NVIC_Init(&NVIC_InitStructure);
    
  TIM_TimeBaseStructure.TIM_Prescaler = 84-1;         //(168Mhz/2)/84 = 1MHz(1us)  //1us
  // TIM_TimeBaseStructure.TIM_Period = 10000-1;        //1us * 10000 =  10ms     
  TIM_TimeBaseStructure.TIM_Period = 4000-1;        //1us * 4000 =  4ms     
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM7, &TIM_TimeBaseStructure);
  //Ÿ�̸�7�� ���۽�Ų��.
  TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
  TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
  TIM_Cmd(TIM7, ENABLE);

  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART2, &USART_InitStructure);

  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE); // USART2 Interrupt enable
  USART_Cmd(USART2, ENABLE);
  
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(USART1, &USART_InitStructure);  
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); // USART1 Interrupt enable
  USART_Cmd(USART1, ENABLE);
  
  Port_Init();
  Init_LCD();
  lcd(0,0,"WELCOME");
  lcd(0,1,"TEST HOME");
  
  WIFI_init();
  sprintf(senddata,"[YJJ_M4:PASSWD]");
  WIFI_send(senddata);
 
  while(1)
  {
    recvdata[0] = 0;
    if(wifi_wait("+IPD","+IPD", 10))  //�������� :  +IPD,6:hello  ������ 0x0a
    {	
      for(i=0;i<5;i++) 
      {
          if(strncmp((char *)uart1_rxdata[i],"+IPD",4)==0) 
          {
                  //sprintf(recvdata,"RECV Data(index:%d,len:%d) : %s\r\n",i,strlen((char *)(uart0_rxdata[i]+8)),uart0_rxdata[i]+8);
                  //printf(recvdata);
                  strcpy(recvdata,(char *)(uart1_rxdata[i]+8));
                  recvdata[strlen((char *)(uart1_rxdata[i]+8)) - 1] = 0;
                  printf(recvdata); 
                  printf("\r\n");
          }
      }
    }

    if(recvdata[0] != 0)
    {
      pToken = strtok(recvdata,"[@]");
      i = 0;

      while(pToken != NULL)
      {
        pArray[i] =  pToken;
        if(i++ >= ARR_CNT)
        break;
        pToken = strtok(NULL,"[@]");
      }

      if(!strncmp(pArray[1]," New con",7))
      {
        printf("TEST01\r\n");
        continue;
      }
      else  if(!strncmp(pArray[1]," Already",7))
      {
        printf("TEST02\r\n");
        WIFI_init();
        sprintf(senddata,"[YJJ_M4:PASSWD]");
        WIFI_send(senddata);
        continue;
      }
      else if(!strncmp(pArray[1],"FIRE",3))
      {
        if(!strncmp(pArray[2],"ON",2))
        {
          fire_flag = 1;
          sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
          lcd(0,0,"WARNING!!!");
          lcd(0,1,"EVACUATE!!!!");
          GPIO_SetBits(GPIOC, GPIO_Pin_14|GPIO_Pin_15);
        }
        else if(!strncmp(pArray[2],"OFF",3))
        {
          fire_flag = 0;
          GPIO_ResetBits(GPIOB, GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
          sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
          lcd(0,0,"WELCOME");
          lcd(0,1,"TEST HOME");
          GPIO_ResetBits(GPIOC, GPIO_Pin_14|GPIO_Pin_15);
        }
      }
    }
  }
}


 

